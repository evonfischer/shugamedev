﻿using UnityEngine;
using System.Collections;



public class Movement : MonoBehaviour {
	
	
	float speed = 18.0f;
	float rotation = 0.0f;
	
	// Update is called once per frame
	void Update ()
	{

	 float x = Input.GetAxis("Horizontal") * Time.smoothDeltaTime * speed;
     float y = Input.GetAxis("Vertical") * Time.smoothDeltaTime * speed;
     transform.Translate(x,0,y,Space.Self);

			
	      if (Input.GetKey(KeyCode.LeftShift)) // sprint
        {
           speed = 50.0f;
        }
		else
		{
			speed = 18.0f;
		}
		
		  if (Input.GetKey(KeyCode.D)) // fucking around with rotate
		{
		rotation += 5.2f;
		//transform.Translate(0,0,rotation * Time.deltaTime);
	//		 transform.Rotate(Vector3.up, speed * Time.deltaTime); // do W + S ?
		}
    
	}
}
